package escritura;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
public class EscrituraArchivo {
    FileWriter ou= null;
    PrintWriter arch = null;
    public void escribirPalabras (File archivo){
        try {
            ou  = new FileWriter (archivo, true);
            arch = new PrintWriter(ou);
            arch.println("Lunes");
            arch.println("Martes");
            arch.println("Miercoles");
            arch.println("Jueves");
            arch.println("Sabado");
            arch.println("Domingo");
        } catch (IOException ex) {
            System.out.println("Error de escritura" + ex.getMessage());
        }
        finally{
            arch.close();
        }
    }
}