package ejarchivo;
import escritura.EscrituraArchivo;
import java.io.File;
import lectura.leerArchivos;
import archSerializado.*;
public class EjArchivo {
    public static void main(String[] args) {
        /*
        en la misma carpeta
        
        File f = new File("pikachonumeros.txt");
        leerArchivos leer = new leerArchivos();
        leer.leerPalabras(f);
        */
        
        /*
        en otra carpeta
        
        File f = new File("/home/dam1/Escritorio/holaadios.txt");
        leerArchivos leer = new leerArchivos();
        leer.leerPalabras(f);
        */
        
        /*
        EscrituraArchivo es = new EscrituraArchivo();
        leerArchivos leer = new leerArchivos();
        
        File f = new File ("dia");
        es.escribirPalabras(f);
        
        leer.leerPalabras(f,"\n");
        */
        
        
        //
        
        File f = new File("Serializado.dat");
        lecEscrituraSerializado se = new lecEscrituraSerializado();
        se.escribirSeri(f);
        se.lerSerializable(f);
        se.añadirSeri(f);
        se.lerSerializable(f);
        
        
        
        
        
    }
}