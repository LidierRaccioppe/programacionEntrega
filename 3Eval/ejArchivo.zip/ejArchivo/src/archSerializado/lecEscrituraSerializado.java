package archSerializado;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class lecEscrituraSerializado {
        ObjectOutputStream escr = null;
        ObjectInputStream lect = null;
    public void escribirSeri (File fich){
        try{
            escr = new ObjectOutputStream (new FileOutputStream (fich));
            AlumnoSerializado al1 = new AlumnoSerializado("aa",5);
            AlumnoSerializado al2 = new AlumnoSerializado("bb",6);
            AlumnoSerializado al3 = new AlumnoSerializado("cc",7);
            escr.writeObject(al1);
            escr.writeObject(al2);
            escr.writeObject(al3);
        }catch(FileNotFoundException ex){
            System.out.println("Error 1, no se pudo escribir en el archivo"+ex.getMessage());
        }catch(IOException ex){
            System.out.println("Error 2, no se pudo escribir en el archivo"+ex.getMessage());
    }finally{
            try{
                escr.close();
            }catch (IOException ex){
                System.out.println("error al cerrar el archivo");
            }
        }
    }
    public void lerSerializable (File Fich){
        AlumnoSerializado a1 = null; 
        try{
            lect = new ObjectInputStream (new FileInputStream(Fich));
            a1 = (AlumnoSerializado)lect.readObject();
            while(a1!=null){
                System.out.println(a1);
                a1 = (AlumnoSerializado)lect.readObject();
            }
        }catch (ClassNotFoundException ex){
            System.out.println("Error lectura 1 "+ex.getMessage());
        }catch (FileNotFoundException ex){
            System.out.println("Error lectura 2 "+ex.getMessage());
        }catch (IOException ex){
            System.out.println("Error lectura 3 "+ex.getMessage());
        }finally{
            try{
                lect.close();
            }catch (IOException ex){
                System.out.println(" error al cerrar el archivo");
            }
        }
    }
    public void añadirSeri (File fich){
        MeuObjectOutputStream escr = null;
        try{
            escr = new MeuObjectOutputStream (new FileOutputStream (fich,true));
            AlumnoSerializado al1 = new AlumnoSerializado("qq",5);
            AlumnoSerializado al2 = new AlumnoSerializado("ww",6);
            
            escr.writeObject(al1);
            escr.writeObject(al2);
        }catch(FileNotFoundException ex){
            System.out.println("Error 1, no se pudo escribir en el archivo"+ex.getMessage());
        }catch(IOException ex){
            System.out.println("Error 2, no se pudo escribir en el archivo"+ex.getMessage());
    }finally{
            try{
                escr.close();
            }catch (IOException ex){
                System.out.println("error al cerrar el archivo");
            }
        }
    }
}