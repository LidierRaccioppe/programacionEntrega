package boletin18;
public class TemperaturaErradaExcepcion extends Exception{
    public TemperaturaErradaExcepcion(){
        super();
    }
    public TemperaturaErradaExcepcion(String mensage){
        super(mensage);
    }
    
    
}