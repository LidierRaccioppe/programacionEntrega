package ejemploclasesabstractas;
public class EjemploClasesAbstractas {
    public static void main(String[] args) {
        Rectangulo re = new Rectangulo(4,2);
        System.out.println("Area Rectangulo = "+re.calcularArea());
        System.out.println("Perimetro Rectangulo = "+re.calcularPerimetro());
        Triangulo tr =  new Triangulo(4,2);
        System.out.println("Area Triangulo = "+tr.calcularArea());
        System.out.println("Perimetro Triangulo = "+tr.calcularPerimetro());
        FigurasGeometricas GeoRe = new Rectangulo(4,2);
        System.out.println("Area Rectangulo = "+GeoRe.calcularArea());
        System.out.println("Perimetro Rectangulo = "+GeoRe.calcularPerimetro());
        // cateto a + cateto b + Math.sqrt(Math.pow(super.getAltura,2)+super.getBase,2),2)
        
    }
}