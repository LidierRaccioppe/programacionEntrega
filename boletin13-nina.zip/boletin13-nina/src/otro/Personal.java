package otro;
public class Personal {
    int telefono;
    String correo;
    public Personal(){
    }
    public void Personal(int telefono, String correo) {
    this.telefono= telefono;
    this.correo= correo;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    @Override
    public String toString() {
        return "Personal{" + "telefono=" + telefono + ", correo=" + correo + '}';
    }
    
    
    
}
