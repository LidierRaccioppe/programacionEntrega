package boletin13.nina;
import otro.Personal;
public class Academica {
    private int nota;
    private String nome;
    private static int numRef=2018;
    private Personal alum = new Personal();
    
    
    
    
    
}
